function msg(){
alert("The form is registered successfully.");
}

function validateform()
{
var name=document.myform.name.value;
var password=document.myform.password.value;
if(name==null || name==""){
alert("name can't be blank");
return false;
}
else if(password.length<7){
alert("password must be atleast 7characters long");
return false;
}}